void ShowError(const WCHAR* message);
void PrintDebugString(const char* format, ...);